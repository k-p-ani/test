package com.atos.controller;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.conn.HttpHostConnectException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.atos.config.security.SecurityConstants;
import com.atos.context.SelfServiceUserContext;
import com.atos.model.CreateProjectModel;
import com.atos.model.DeleteProjectModel;
import com.atos.service.OpenShiftLogin;
import com.atos.service.ProjectService;
import com.google.gson.GsonBuilder;

@Controller
@RequestMapping(value = "/project")
public class ProjectController extends SelfServiceControler {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProjectController.class);
	private static final String ADD_PROJECT_SUCCESS = "Project %s created successfully";
	private static final String DELETE_PROJECT_SUCCESS = "Project %s deleted successfully";
	private static final String INCORRECT_HOST = "unknown host : '%s' ";
    private static final String CONNECTION_TIMEOUT = "Unable to connect to host '%s' : Connection timeout ";
    private static final String CONNECTION_GENERIC_EXCEPTION = "cannot connect to server '%s' ";

	@Autowired
	private ProjectService projectService;
	@Autowired
	private OpenShiftLogin openshiftLogin;
	@Autowired
	private SelfServiceUserContext userContext;

	@RequestMapping(value = "/addProject", method = RequestMethod.GET)
	public String createProject(Model model, HttpServletResponse response,
			@CookieValue(value = SecurityConstants.OS_ACCOUNT_USER_TOKEN, defaultValue = "") String token) {

		model.addAttribute("listofApi", getOpenShiftServers());
		LOGGER.info("ProjectController addProject  :: GET :: Begin");
		CreateProjectModel createProjectModel = new CreateProjectModel();
		model.addAttribute("add_project", createProjectModel);
		LOGGER.info("ProjectController addProject  :: GET :: End");
		if (!token.isEmpty()) {
			setHttpResponseHeader(response, token);
		}
		return "addProject";
	}

	@RequestMapping(value = "/addProject", method = RequestMethod.POST)
	public String createProject(@ModelAttribute CreateProjectModel createProjectModel, HttpServletResponse response,
			RedirectAttributes redirectAttributes,
			@CookieValue(value = SecurityConstants.OS_ACCOUNT_USER_TOKEN, defaultValue = "") String token) {

		if (token.isEmpty()) {
			token = openshiftLogin.login(createProjectModel.getClusterName());
			System.out.println("createProject  token received from openshift " + token);
		}

		LOGGER.info("ProjectController addProject  :: POST :: Begin");
		LOGGER.debug("name " + createProjectModel.getProjectName());
		LOGGER.debug("display name " + createProjectModel.getDisplayName());
		LOGGER.debug("description " + createProjectModel.getDescription());
		projectService.createProject(createProjectModel, token, userContext.getUserOrganisationName(),createProjectModel.getClusterName());
		LOGGER.info("ProjectController addProject  :: POST :: End");
		String successmessage = String.format(ADD_PROJECT_SUCCESS, createProjectModel.getProjectName());
		redirectAttributes.addFlashAttribute("message", successmessage);
		redirectAttributes.addFlashAttribute("alertClass", "alert-success");

		setHttpResponseHeader(response, token);
		return "redirect:/project/addProject";

	}

	@RequestMapping(value = "/deleteProject", method = RequestMethod.GET)
	public String deleteProject(ModelMap model, HttpServletResponse response,
			@CookieValue(value = SecurityConstants.OS_ACCOUNT_USER_TOKEN, defaultValue = "") String token) {

		/*
		 * LOGGER.debug("ProjectController deleteProject  :: GET :: token ---> "+token);
		 * if(token.isEmpty()) { token = openshiftLogin.login(""); LOGGER.
		 * debug("ProjectController deleteProject  :: GET :: token return from login ---> "
		 * +token); }
		 */
		model.addAttribute("listofApi", getOpenShiftServers());
		LOGGER.debug("ProjectController deleteProject  :: GET :: Begin");
		List<String> listOfProjects = new ArrayList<>();
		DeleteProjectModel deleteProjectModel = new DeleteProjectModel();
		// listOfProjects =
		// projectService.listProjects(token,userContext.getUserOrganisationName());
		
		model.addAttribute("delete_project", deleteProjectModel);
		model.addAttribute("listofproject", listOfProjects);
		LOGGER.debug("ProjectController deleteProject  :: GET :: End");
		setHttpResponseHeader(response, token);
		return "deleteProject";
	}

	@RequestMapping(value = "/deleteProject", method = RequestMethod.POST)
	public String deleteProject(@ModelAttribute DeleteProjectModel deleteProjectModel, HttpServletResponse response,
			RedirectAttributes redirectAttributes, 
			@CookieValue(value = SecurityConstants.OS_ACCOUNT_USER_TOKEN, defaultValue = "") String token) {

		System.out.println("here");
		LOGGER.debug("ProjectController deleteProject selected cluster :: POST ::  " + deleteProjectModel.getClusterName());
		/*
		 * if (token.isEmpty()) { token =
		 * openshiftLogin.login(deleteProjectModel.getClusterName()); LOGGER.
		 * debug("ProjectController deleteProject retrieved :: POST :: token return from login ---> "
		 * + token); }
		 */
		
		List<String > projects11 = deleteProjectModel.getProjectName();
		
		for (String string : projects11) {
			System.out.println("**************"+string);
		}
	
		LOGGER.debug("ProjectController deleteProject  :: POST :: token return from login ---> " + token);
		projectService.deleteProject(deleteProjectModel, token, userContext.getUserOrganisationName(),null);
		LOGGER.debug("ProjectController deleteProject  :: POST :: End");
		ModelMap model = new ModelMap();
		setHttpResponseHeader(response, token);
		deleteProject(model, response, token);
		if (deleteProjectModel.getProjectName() != null && !deleteProjectModel.getProjectName().isEmpty()) {
			String projects = deleteProjectModel.getProjectName().stream().map(n -> String.valueOf(n))
					.collect(Collectors.joining(",", "(", ")"));
			String successmessage = String.format(DELETE_PROJECT_SUCCESS, projects);
			redirectAttributes.addFlashAttribute("message", successmessage);
			redirectAttributes.addFlashAttribute("alertClass", "alert-success");
		}
		return "redirect:/project/deleteProject";
	}

	private void setHttpResponseHeader(HttpServletResponse response, String cookie) {
		Cookie cookieObj = new Cookie(SecurityConstants.OS_ACCOUNT_USER_TOKEN, cookie);
		cookieObj.setHttpOnly(true);
		response.addCookie(cookieObj);
	}

	
	
	
	
	@RequestMapping(value = "/listProjects", method = RequestMethod.POST)
	public String listProjects(ModelMap model, @RequestParam("clusterName") String env, HttpServletRequest req, 
			RedirectAttributes redirectAttributes,
			HttpServletResponse response,
			@CookieValue(value = SecurityConstants.OS_ACCOUNT_USER_TOKEN, defaultValue = "") String token )  {
		LOGGER.debug("ProjectController listProjects  :: GET :: token ---> " + token);
		
		try {
			System.out.println("post me ");
			
			
			  if (token.isEmpty()) 
			  {
				  token = openshiftLogin.login(env); 
				  LOGGER. debug("ProjectController listProjects  :: GET :: token return from login ---> "
			  + token); }
			 
			  

			List<String> listOfProjects = projectService.listProjects(token, userContext.getUserOrganisationName(),env);
			
			//List<String> listOfProjects = new ArrayList<>();
			
			/*
			 * hardcoding 
			 * if(env.contains("admin")) { System.out.println("admin");
			 * //listOfProjects.add("dev_project1"); //listOfProjects.add("dev_project2");
			 * 
			 * } else { System.out.println("test"); listOfProjects.add("test_project1");
			 * listOfProjects.add("test_project2"); }
			 */
			
			if(listOfProjects.isEmpty()) {
				System.out.println("empty");
				
				model.addAttribute("val","block;");
				model.addAttribute("val1","none;");
				return "deleteProject::#items";
			}
			else {
			
			DeleteProjectModel deleteProjectModel = new DeleteProjectModel();
			deleteProjectModel.setClusterName(env);
			model.addAttribute("delete_project", deleteProjectModel);
			model.addAttribute("listofproject", listOfProjects);
			model.addAttribute("val1","block;");
			model.addAttribute("val","none;");
			//return new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create().toJson(listOfProjects);
			return "deleteProject::#items";
			}
			} catch (Exception ex) {
			System.out.println("in catch ");
			List<String> listOfProjects = new ArrayList<>();
			// TODO: handle exception
			response.setStatus(400);
			model.addAttribute("listProject", listOfProjects);
			model.addAttribute("alertClass", "alert-danger");
			model.addAttribute("val","block;");
			if (ex.getCause() instanceof HttpHostConnectException) {
				model.addAttribute("message", String.format(CONNECTION_TIMEOUT, req.getParameter("clusterName")));
			} else if (ex.getCause() instanceof UnknownHostException) {
				model.addAttribute("message", String.format(INCORRECT_HOST,req.getParameter("clusterName")));
			}else {
				System.out.println("hell");
				model.addAttribute("message", String.format(CONNECTION_GENERIC_EXCEPTION,req.getParameter("clusterName")));
			}
		return "deleteProject::#success_message";
		}
	}
}
