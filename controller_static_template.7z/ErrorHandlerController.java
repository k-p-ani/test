
package com.atos.controller;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.conn.HttpHostConnectException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.ldap.NameNotFoundException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import com.atos.exceptions.AnnotateProjectFailedException;
import com.atos.exceptions.CreateProjectFailedException;
import com.atos.exceptions.DeleteProjectFailedException;
import com.atos.exceptions.GetAllProjectsFailedException;
import com.atos.exceptions.GroupNotFoundException;
import com.atos.exceptions.JWTTokenExpiredException;
import com.atos.exceptions.RoleBindingFailedException;
import com.atos.exceptions.UserCreationFailedException;
import com.atos.model.ExceptionResponseEntity;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;

/**
 * 
 * @class Centralize Exception Handling Class , Any exception caught in the
 *        server will be handled in this class.
 */
@ControllerAdvice
public class ErrorHandlerController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ErrorHandlerController.class);
	
	private static final String GENERIC_EXCEPTION =  "Unable to perform operation , please contact operations team";
	private static final String DUPLICATE_USERNAME_EXCEPTION ="duplicate name found in server";
	private static final String DUPLICATE_PROJECTNAME_EXCEPTION="Project with this name already Exists";
    private static final String REDIRECT= "redirect:"; 
    private static final String INCORRECT_HOST = "unknown host : '%s' ";
    private static final String CONNECTION_TIMEOUT = "Unable to connect to host '%s' : Connection timeout ";
    private static final String CONNECTION_GENERIC_EXCEPTION = "cannot connect to server '%s' ";
    private static final String NAME_NOT_FOUND = "user '%s' not found";   
    @Autowired
	private ExceptionResponseEntity exceptionResponseEntity;

	public static final String DEFAULT_ERROR_VIEW = "defaultError";

	@ExceptionHandler(InvalidFormatException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public @ResponseBody ExceptionResponseEntity badRequest() {
		exceptionResponseEntity.setCode(HttpStatus.BAD_REQUEST.toString());
		return exceptionResponseEntity;
	}

	@ExceptionHandler(AnnotateProjectFailedException.class)
	public String annotateProjectFailedException(AnnotateProjectFailedException name , RedirectAttributes redirectAttributes ,HttpServletRequest req) {
		LOGGER.info("AnnotateProjectFailedException Error Handler Invoked :: Begin");
		redirectAttributes.addFlashAttribute("message", name.getErrorMessage());
		redirectAttributes.addFlashAttribute("alertClass", "alert-danger");
		redirectAttributes.addFlashAttribute("val","block;");
		LOGGER.error("ErrorHandlerController annotateProjectFailedException ",name);
		LOGGER.info("AnnotateProjectFailedException Invoked :: End ");
		//return "redirect:/project/addProject";
		return REDIRECT+req.getRequestURI();
	}

	@ExceptionHandler(CreateProjectFailedException.class)
	public String createProjectFailedException(CreateProjectFailedException name , RedirectAttributes redirectAttributes,HttpServletRequest req ) {
		LOGGER.info("CreateProjectFailedException Error Handler Invoked :: Begin");
		redirectAttributes.addFlashAttribute("message", name.getErrorMessage());
		redirectAttributes.addFlashAttribute("alertClass", "alert-danger");
		redirectAttributes.addFlashAttribute("val","block;");
		LOGGER.error("ErrorHandlerController createProjectFailedException ",name);
		LOGGER.info("CreateProjectFailedException Invoked :: End ");
		//return "redirect:/project/addProject";
		return REDIRECT+req.getRequestURI();
	}

	@ExceptionHandler(DeleteProjectFailedException.class)
	public String deleteProjectFailedException(DeleteProjectFailedException name , RedirectAttributes redirectAttributes,HttpServletRequest req ) {
		LOGGER.info("DeleteProjectFailedException Error Handler Invoked :: Begin");
		redirectAttributes.addFlashAttribute("message", name.getErrorMessage());
		redirectAttributes.addFlashAttribute("alertClass", "alert-danger");
		redirectAttributes.addFlashAttribute("val","block;");
		LOGGER.error("ErrorHandlerController deleteProjectFailedException ",name);
		LOGGER.info("DeleteProjectFailedException Invoked :: End ");
		//return "redirect:/project/deleteProject";
		return REDIRECT+req.getRequestURI();
	}
	
	//TODO if this exception get raised from deleteProject/addUser then which url to returned
	@ExceptionHandler(GetAllProjectsFailedException.class)
	public String getAllProjectsFailedException(GetAllProjectsFailedException name , RedirectAttributes redirectAttributes,HttpServletRequest req ) {
		LOGGER.info("GetAllProjectsFailedException Error Handler Invoked :: Begin");
		redirectAttributes.addFlashAttribute("message", name.getErrorMessage());
		redirectAttributes.addFlashAttribute("alertClass", "alert-danger");
		redirectAttributes.addFlashAttribute("val","block;");
		LOGGER.error("ErrorHandlerController getAllProjectsFailedException ",name);
		LOGGER.info("GetAllProjectsFailedException Invoked :: End ");
		//return "redirect:/user/addUser";
		
		return REDIRECT+req.getRequestURI();
	}
	
	
	@ExceptionHandler(ResourceAccessException.class)
	public String resourceAccessException(ResourceAccessException ex , RedirectAttributes redirectAttributes , HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		LOGGER.info("ResourceAccessException Error Handler Invoked :: Begin");
		LOGGER.error("ErrorHandlerController ResourceAccessException ",ex);
		redirectAttributes.addFlashAttribute("alertClass", "alert-danger");
		redirectAttributes.addFlashAttribute("val","block;");
		if (ex.getCause() instanceof HttpHostConnectException) {
			redirectAttributes.addFlashAttribute("message", String.format(CONNECTION_TIMEOUT, req.getParameter("clusterName")));
		} else if (ex.getCause() instanceof UnknownHostException) {
			redirectAttributes.addFlashAttribute("message", String.format(INCORRECT_HOST,req.getParameter("clusterName")));
		} else {
			redirectAttributes.addFlashAttribute("message", String.format(CONNECTION_GENERIC_EXCEPTION,req.getParameter("clusterName")));
		}
		
		return REDIRECT+req.getRequestURI();
		
	}
	
	@ExceptionHandler(RoleBindingFailedException.class)
	public String roleBindingFailedException(RoleBindingFailedException name , RedirectAttributes redirectAttributes , HttpServletRequest req) {
		LOGGER.info("RoleBindingFailedException Error Handler Invoked :: Begin");
		redirectAttributes.addFlashAttribute("message", name.getErrorMessage());
		redirectAttributes.addFlashAttribute("alertClass", "alert-danger");
		redirectAttributes.addFlashAttribute("val","block;");
		LOGGER.error("ErrorHandlerController roleBindingFailedException ",name);
		LOGGER.info("RoleBindingFailedException Invoked :: End ");
		//return "redirect:/project/addProject";
		return REDIRECT+req.getRequestURI();
	}
	
	@ExceptionHandler(NullPointerException.class)
	public String  nullPointerException(NullPointerException ex , HttpServletRequest req ,RedirectAttributes redirectAttributes) {
		LOGGER.info("Null pointer exception Handler Invoked :: Begin");
		redirectAttributes.addFlashAttribute("message", GENERIC_EXCEPTION);
		redirectAttributes.addFlashAttribute("alertClass", "alert-danger");
		redirectAttributes.addFlashAttribute("val","block;");
		LOGGER.error("ErrorHandlerController nullPointerException ",ex);
		LOGGER.info("Null pointer exception Handler Invoked :: End");
		return REDIRECT+req.getRequestURI();
	}

	@ExceptionHandler(HttpClientErrorException.class)
	public  String javaxexception(HttpClientErrorException name , RedirectAttributes redirectAttributes,HttpServletRequest req) {

		LOGGER.info("Conflict Error Handler Invoked :: Begin");
		redirectAttributes.addFlashAttribute("message", DUPLICATE_PROJECTNAME_EXCEPTION);
		redirectAttributes.addFlashAttribute("alertClass", "alert-danger");
		redirectAttributes.addFlashAttribute("val","block;");
		LOGGER.error("ErrorHandlerController HttpClientErrorException ",name);
		LOGGER.info("Error Handler Invoked :: End ");
		//return "redirect:/project/addProject";
		return REDIRECT+req.getRequestURI();
		
	}
	
	@ExceptionHandler(UserCreationFailedException.class)
	public String userCreationFailedException(UserCreationFailedException name , RedirectAttributes redirectAttributes , HttpServletRequest req) {
		LOGGER.info("UserCreationFailedException Error Handler Invoked :: Begin");
		redirectAttributes.addFlashAttribute("message", name.getErrorMessage());
		redirectAttributes.addFlashAttribute("alertClass", "alert-danger");
		redirectAttributes.addFlashAttribute("val","block;");
		LOGGER.error("ErrorHandlerController userCreationFailedException ",name);
		LOGGER.info("UserCreationFailedException Invoked :: End ");
		//return "redirect:/user/addUser";
		return REDIRECT+req.getRequestURI();
	}
	
	
	@ExceptionHandler(GroupNotFoundException.class)
	public String groupNotFound(GroupNotFoundException e , RedirectAttributes redirectAttributes , HttpServletRequest req) {
		LOGGER.info("GroupNotFoundException Error Handler Invoked :: Begin");
		redirectAttributes.addFlashAttribute("message",e.getErrorMessage());
		redirectAttributes.addFlashAttribute("alertClass", "alert-danger");
		redirectAttributes.addFlashAttribute("val","block;");
		LOGGER.error("ErrorHandlerController GroupNotFoundException ",e);
		LOGGER.info("GroupNotFoundException Invoked :: End ");
		
		return REDIRECT+req.getRequestURI();
	}
	
	
	@ExceptionHandler(JWTTokenExpiredException.class)
	public String tokenExpiredException(JWTTokenExpiredException name , RedirectAttributes redirectAttributes ) {
		LOGGER.info("JWTTokenExpiredException Error Handler Invoked :: Begin");
		redirectAttributes.addFlashAttribute("message", name.getMessage());
		redirectAttributes.addFlashAttribute("alertClass", "alert-danger");
		redirectAttributes.addFlashAttribute("val","block;");
		LOGGER.error("ErrorHandlerController tokenExpiredException ",name);
		LOGGER.info("JWTTokenExpiredException Invoked :: End ");
		return "redirect:/tokenError";	
	}
	
	@ExceptionHandler(NameNotFoundException.class)
	public String NameNotFound(NameNotFoundException e,RedirectAttributes redirectAttributes , HttpServletRequest req) {
		LOGGER.info("NameNotFoundInLdapServer Error Handler Invoked :: Begin");
		redirectAttributes.addFlashAttribute("message",String.format(NAME_NOT_FOUND, req.getParameter("userName")) );
		redirectAttributes.addFlashAttribute("alertClass", "alert-danger");
		redirectAttributes.addFlashAttribute("val","block;");
		LOGGER.error("ErrorHandlerController GroupNotFoundException ",e);
		LOGGER.info("JWTTokenExpiredException Invoked :: End ");
		return REDIRECT+req.getRequestURI();
	}
	
	
	@ExceptionHandler(Exception.class)
	public String exception(Exception ex, RedirectAttributes redirectAttributes , HttpServletRequest req ) {
	System.out.println("in generic ");
		//	LOGGER.info("Generic Error Handler Invoked :: Begin");
		LOGGER.error("ErrorHandlerController exception ",ex);
		redirectAttributes.addFlashAttribute("message", GENERIC_EXCEPTION);
		redirectAttributes.addFlashAttribute("alertClass", "alert-danger");
		redirectAttributes.addFlashAttribute("val","block;");
//		LOGGER.info("Error Handler Invoked :: End ");
		System.out.println("****************"+req.getRequestURI());
		return REDIRECT+req.getRequestURI();
	}
}
