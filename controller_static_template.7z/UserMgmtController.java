package com.atos.controller;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.conn.HttpHostConnectException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.NameAlreadyBoundException;
import org.springframework.ldap.NameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.atos.config.security.SecurityConstants;
import com.atos.context.SelfServiceUserContext;
import com.atos.model.CreateUserModel;
import com.atos.model.DeleteUserModel;
import com.atos.service.OpenShiftLogin;
import com.atos.service.ProjectService;
import com.atos.service.UserMgmtService;
import com.google.gson.GsonBuilder;

@Controller
@RequestMapping(value = "/user")
public class UserMgmtController extends SelfServiceControler{

	private static final Logger LOGGER = LoggerFactory.getLogger(UserMgmtController.class);
	private static final String ADD_USER_SUCCESS="User %s created and associated with project %s successfully";
	private static final String DELETE_USER_SUCCESS="User %s deleted successfully";
	private static final String INCORRECT_HOST = "unknown host : '%s' ";
    private static final String CONNECTION_TIMEOUT = "Unable to connect to host '%s' : Connection timeout ";
    private static final String CONNECTION_GENERIC_EXCEPTION = "cannot connect to server '%s' ";
	   
	
	@Autowired
	UserMgmtService usermgmtservice;

	@Autowired
	private ProjectService projectService;
	
	@Autowired
	private OpenShiftLogin openshiftLogin;
	@Autowired
	private SelfServiceUserContext userContext;
	
	@RequestMapping(value = "/addUser", method = RequestMethod.GET)
	public String addUser(Model model, @CookieValue(value=SecurityConstants.OS_ACCOUNT_USER_TOKEN,defaultValue ="") String token,HttpServletResponse response) {
		LOGGER.info("UserMgmtController addUser  :: GET :: Begin");
		CreateUserModel createUserModel = new CreateUserModel();
		List<String> listOfProjects = new ArrayList<>();
		model.addAttribute("listofApi", getOpenShiftServers());
		model.addAttribute("listProject", listOfProjects);
		model.addAttribute("add_user", createUserModel);
		if(token.isEmpty()) {
			setHttpResponseHeader(response, token);
		}
		LOGGER.info("UserMgmtController addUser  :: GET :: End");
		return "addUser";
	}

	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	public String addUserToGroup(@ModelAttribute CreateUserModel createUserModel, RedirectAttributes redirectAttributes)
			throws NameAlreadyBoundException {
		
		LOGGER.info("UserMgmtController addUser  :: POST :: Begin");
		LOGGER.debug(String.format("createUser createUserModel %s", createUserModel));
		usermgmtservice.addUserToAdminGroup(createUserModel,userContext.getUserOrganisationName());
		String successmessage = String.format(ADD_USER_SUCCESS, createUserModel.getUserName(),createUserModel.getProjectName());
		redirectAttributes.addFlashAttribute("message", successmessage);
		redirectAttributes.addFlashAttribute("alertClass", "alert-success");
		LOGGER.info("UserMgmtController addUser  :: POST :: End");
		return "redirect:/user/addUser";

	}

	@RequestMapping(value = "/deleteUser", method = RequestMethod.GET)
	public String deleteUser(Model model) {
		LOGGER.info("UserMgmtController deleteUser  :: GET :: Begin");
		List<String> listOfUsers= new ArrayList<String>();
		model.addAttribute("listofApi", getOpenShiftServers());
		LOGGER.debug(String.format("deleteUser GET model %s", model));
		DeleteUserModel deleteProjectModel = new DeleteUserModel();
		
		//listOfUsers = usermgmtservice.listUser();
		//listOfUsers.add("user1");
		//listOfUsers.add("user2");
		//listOfUsers.add("user3");
		model.addAttribute("delete_user", deleteProjectModel);
		model.addAttribute("listofuser", listOfUsers);
		model.addAttribute("listofApi", getOpenShiftServers());
		LOGGER.info("UserMgmtController deleteUser  :: GET :: End");
		System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
		return "deleteUser";
	}

	@RequestMapping(value = "/deleteUser", method = RequestMethod.POST)
	public String deleteUser(@ModelAttribute DeleteUserModel deleteUserModel, RedirectAttributes redirectAttributes) throws NameNotFoundException {
		LOGGER.info("UserMgmtController deleteUser  :: POST :: Begin");
		LOGGER.debug(String.format("deleteUser POST deleteUserModel %s", deleteUserModel));
		usermgmtservice.deleteUserItselfAndFromGroup(deleteUserModel);
		LOGGER.info("UserMgmtController deleteUser  :: POST :: End");
		if (deleteUserModel.getUserName() != null && !deleteUserModel.getUserName().isEmpty()) {
			String projects = deleteUserModel.getUserName().stream().map(n -> String.valueOf(n)).collect(Collectors.joining(",", "(", ")"));
			String successmessage = String.format(DELETE_USER_SUCCESS, projects);
			redirectAttributes.addFlashAttribute("message", successmessage);
			redirectAttributes.addFlashAttribute("alertClass", "alert-success");
		}
		
		return "redirect:/user/deleteUser";
	}
	
	private void setHttpResponseHeader(HttpServletResponse response, String cookie) {
		Cookie cookieObj = new Cookie(SecurityConstants.OS_ACCOUNT_USER_TOKEN, cookie);
		cookieObj.setHttpOnly(true);
		response.addCookie(cookieObj);
	}
	
	
	@RequestMapping(value = "/listusers", method = RequestMethod.POST)
	public String listUser( Model model ,@ModelAttribute DeleteUserModel deleteUserModel, RedirectAttributes redirectAttributes) {
		System.out.println("********************************************************");
		List<String> listOfUsers= new ArrayList<String>();
		listOfUsers.add("user1");
		listOfUsers.add("user2");
		listOfUsers.add("user3");
		listOfUsers.add("user4");
		listOfUsers.add("user5");
		listOfUsers.add("user6");
		
		model.addAttribute("delete_user", deleteUserModel);
		model.addAttribute("listofuser", listOfUsers);
		model.addAttribute("listofApi", getOpenShiftServers());
		return "deleteUser::#items";
	}
	
	/*
	 * @RequestMapping(value = "/listProjects", method = RequestMethod.GET) public
	 * String listProjects(ModelMap model,
	 * 
	 * @ModelAttribute("message") String message,
	 * 
	 * @ModelAttribute("alertClass") String alert, RedirectAttributes
	 * redirectAttributes, HttpServletRequest request, HttpServletResponse response,
	 * 
	 * @CookieValue(value = SecurityConstants.OS_ACCOUNT_USER_TOKEN, defaultValue =
	 * "") String token ) { System.out.println("get me "); List<String>
	 * listOfProjects = new ArrayList<>(); CreateUserModel createUserModel = new
	 * CreateUserModel();
	 * LOGGER.debug("ProjectController deleteProject  :: GET :: End");
	 * model.addAttribute("listofApi", getOpenShiftServers());
	 * model.addAttribute("listProject", listOfProjects);
	 * model.addAttribute("add_user", createUserModel);
	 * model.addAttribute("message", message); model.addAttribute("alertClass",
	 * alert);
	 * 
	 * //model.addAttribute("lastSelectedEnv", env);
	 * 
	 * System.out.println("#########"+response.getStatus());
	 * 
	 * return "addUser::#addUser"; }
	 */
	
	@RequestMapping(value = "/listProjects", method = RequestMethod.POST)
	//@ResponseBody
	public String listProjects(ModelMap model, @RequestParam("clusterName") String env, HttpServletRequest req,
			RedirectAttributes redirectAttributes,
			HttpServletResponse response,
			@CookieValue(value = SecurityConstants.OS_ACCOUNT_USER_TOKEN, defaultValue = "") String token) throws IOException {
		
		LOGGER.debug("ProjectController listProjects  :: GET :: token ---> " + token);
		
		try {
			
			System.out.println("in    try ");
			
			
			
			/*
			 * if (token.isEmpty()) { token = openshiftLogin.login(env); LOGGER.
			 * debug("ProjectController listProjects  :: GET :: token return from login ---> "
			 * + token);
			 * 
			 * }
			 * 
			 */
			 
			
			//List<String> listOfProjects = projectService.listProjects(token, userContext.getUserOrganisationName(),env);		//find what exception it can throw 
			
			List<String> listOfProjects = new ArrayList<>();
			
			if(env.contains("admin")) {
				System.out.println("admin");
				  listOfProjects.add("dev21july"); 
				  listOfProjects.add("devtwo");
				 
			}
			else {
				System.out.println("test");
				  listOfProjects.add("testjuly"); 
				  listOfProjects.add("testtwo");
			}
			
			CreateUserModel createUserModel = new  CreateUserModel();
			
			
			createUserModel.setClusterName(env);
			model.addAttribute("listofApi", getOpenShiftServers());
			model.addAttribute("listProject", listOfProjects);
			model.addAttribute("add_user", createUserModel);
			model.addAttribute("lastSelectedEnv", env);
		//   return new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create().toJson(listOfProjects);
			//return "addUser::#addUser";
		  return "addUser::#addfailedset";
			
		}catch (Exception ex ) {
			System.out.println("in catch ");
			List<String> listOfProjects = new ArrayList<>();
			// TODO: handle exception
			response.setStatus(400);
			model.addAttribute("listProject", listOfProjects);
			model.addAttribute("alertClass", "alert-danger");
			String error= "";
			model.addAttribute("val","block;");
			if (ex.getCause() instanceof HttpHostConnectException) {
				model.addAttribute("message", String.format(CONNECTION_TIMEOUT, req.getParameter("clusterName")));
				error=String.format(CONNECTION_TIMEOUT, req.getParameter("clusterName"));
			} else if (ex.getCause() instanceof UnknownHostException) {
				model.addAttribute("message", String.format(INCORRECT_HOST,req.getParameter("clusterName")));
				error = String.format(INCORRECT_HOST,req.getParameter("clusterName"));
			}else {
				System.out.println("hell");
				model.addAttribute("message", String.format(CONNECTION_GENERIC_EXCEPTION,req.getParameter("clusterName")));
				error = String.format(CONNECTION_GENERIC_EXCEPTION,req.getParameter("clusterName"));
			}
			System.out.println(error);
			//return new GsonBuilder().excludeFieldsWithoutExposeAnnotation().setPrettyPrinting().create().toJson(error);
			return "addUser::#success_message";
		}
		  
	}
}
