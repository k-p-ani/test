#!/bin/bash

#Packages list declaration
TARGET=apt-packages

cd $TARGET
sudo apt-get install *.deb || { ./scripts/rollback.sh ; exit 101; }
