#!/bin/bash

FILE=out.txt
FILE_FIXED=outfixed.txt
TARGET=backup/pkg

dobackup() {
  sed -i '/^Fetched\b/d' $FILE
  awk '{ print $5 }' $FILE > outfixed.txt
  IFS=$'\n' read -d '' -r -a lines < $FILE_FIXED
  cd $TARGET
  for pkg in ${lines[@]}; do
    dpkg-query -W $pkg | awk '{print $1}' | xargs dpkg-repack
  done
}

dobackup

