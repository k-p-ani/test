#!/bin/bash

#Rollback packages list
TARGET=../backup/pkg

cd $TARGET
sudo apt-get install *.deb
