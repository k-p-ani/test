#!/bin/bash

#Packages list declaration
TARGET=apt-packages
cd $TARGET
echo "================patching in progress======================"
if sudo dpkg --force-all -i *; then
   echo "================patching completed======================"
else
   echo "================patching failed======================"
   ../scripts/rollback.sh
fi