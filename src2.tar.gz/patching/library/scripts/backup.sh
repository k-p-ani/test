#!/bin/bash

FILE=out.txt
FILE_FIXED=outfixed.txt
TARGET=backup/pkg

dobackup() {
  sed -i '/^Fetched\b/d' $FILE
  awk '{ print $5 }' $FILE > $FILE_FIXED
  IFS=$'\n' read -d '' -r -a lines < $FILE_FIXED
  cd $TARGET
  echo "================backup in progress======================"
  for pkg in ${lines[@]}; do
    sudo dpkg-query -W $pkg | awk '{print $1}' | sudo xargs dpkg-repack
  done
  echo "================backup completed======================"
}

dobackup