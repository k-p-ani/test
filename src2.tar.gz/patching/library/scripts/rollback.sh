#!/bin/bash

#Rollback packages list
TARGET=../backup/pkg
cd $TARGET
echo "================rollback in progress======================"
sudo dpkg --force-all -i *
echo "================rollback completed======================"