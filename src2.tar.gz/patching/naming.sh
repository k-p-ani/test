#!/bin/bash
OSNAME=`lsb_release -d | awk '{print $2}' | tr 'U' 'u'`
OSVER=`lsb_release -d | awk '{print $3}' | tr '.' '_'`
echo $OSNAME-$OSVER